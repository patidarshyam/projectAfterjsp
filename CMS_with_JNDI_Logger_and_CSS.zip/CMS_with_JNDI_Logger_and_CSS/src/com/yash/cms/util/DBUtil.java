package com.yash.cms.util;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import org.apache.jasper.tagplugins.jstl.core.Catch;
import org.apache.log4j.Logger;

import com.yash.cms.model.User;


/**
 * This class will perform operation related to DB like connection, disconnect, providing
 * preparedStatement object and ResultSet object. This class will be responsible to have
 * transaction complete operation as well like closing connection, PreparedStatement object etc.
 * @author shyam.patidar
 *
 */
public class DBUtil {
	private static Logger logger= Logger.getLogger(DBUtil.class);
	private static Context ctx=null;
	private static DataSource ds=null;
	private static Connection con=null;
	public static PreparedStatement pstmt= null;

	/**
	 * This will return the Connection object.
	 * @return
	 */
	public static Connection connect(){
	
		 try {
			ctx = new InitialContext();
			ds = (DataSource) ctx.lookup("java:/comp/env/jdbc/cms");
			con = ds.getConnection();
			logger.info("con object : "+con);
		} catch (NamingException e) {
			logger.error("ERROR : "+ e);
		} catch (SQLException e) {
			logger.error("ERROR : "+ e);
		}
	return con;
	}
	/**
	 * This method will return the PreparedStatement object based on the sql provided.
	 * This method should have call for connection because when you need transaction, that time
	 * you will require connection object.
	 * @param sql is any dml query
	 * @return
	 */
	public static PreparedStatement createPreparedstatement(String sql){
		connect();
		try {
			pstmt=con.prepareStatement(sql);
			logger.info(pstmt);
		} catch (SQLException e) {
			logger.error("ERROR : "+ e);
		}
		return pstmt;
	}
	
}
