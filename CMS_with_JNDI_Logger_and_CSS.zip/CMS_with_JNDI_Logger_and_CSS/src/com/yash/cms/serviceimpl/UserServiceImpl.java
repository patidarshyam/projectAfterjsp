package com.yash.cms.serviceimpl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.yash.cms.dao.UserDAO;
import com.yash.cms.daoimpl.UserDAOImpl;
import com.yash.cms.model.User;
import com.yash.cms.service.UserService;
import com.yash.cms.util.DBUtil;

public class UserServiceImpl implements UserService{
	private static Logger logger= Logger.getLogger(UserServiceImpl.class);
	private UserDAO userDAO=null;
	public UserServiceImpl() {
		userDAO= new UserDAOImpl(); //DI (Dependency Injection)
	}

	@Override
	public void registerUser(User user) {
		userDAO.insert(user);
	}

	@Override
	public User userAuthentication(String loginName,String password) {
		PreparedStatement pstmt=null;
		User user=null;
		try {
			String sql="select * from users where loginName='"+loginName+"' and password='"+password+"'";
			pstmt=DBUtil.createPreparedstatement(sql);
			ResultSet rs = pstmt.executeQuery();
			
			if(rs.next()){
				user=new User();
				user.setName(rs.getString("name"));
				user.setContact(rs.getString("contact"));
				user.setEmail(rs.getString("email"));
				user.setId(rs.getInt("id"));
				user.setRole(rs.getInt("role"));
			}
			logger.info("INFO : User authentication run");
		} catch (SQLException e) {
			logger.error("Error : "+e);
		}
		return user;	
	}
}
