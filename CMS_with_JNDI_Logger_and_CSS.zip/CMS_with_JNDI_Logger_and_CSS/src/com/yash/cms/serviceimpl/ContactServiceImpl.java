package com.yash.cms.serviceimpl;

import java.util.List;

import org.apache.log4j.Logger;

import com.yash.cms.dao.ContactDAO;
import com.yash.cms.daoimpl.ContactDAOImpl;
import com.yash.cms.model.Contact;
import com.yash.cms.service.ContactService;

public class ContactServiceImpl implements ContactService {
	private static Logger logger= Logger.getLogger(ContactServiceImpl.class);
	private ContactDAO contactDAO=null;
	public ContactServiceImpl() {
		contactDAO=new ContactDAOImpl();
	}
	
	@Override
	public void addContact(Contact contact) {
		contactDAO.insert(contact);
	}

	@Override
	public List<Contact> getAllContactByUserId(Integer userId) {
		List<Contact> contacts=contactDAO.listContact(userId);
		return contacts;
	}

	@Override
	public void deleteContact(Integer contactId) {
		contactDAO.delete(contactId);
	}

	@Override
	public void updateContact(Contact contact) {
	contactDAO.update(contact);
		
	}

	@Override
	public Contact getContact(Integer contactId) {
		Contact contact= contactDAO.select(contactId);
		return contact;
	}

	@Override
	public List<Contact> searchData(String search, Integer userId) {
		List<Contact> contacts=contactDAO.listContact(search,userId);
		return contacts;
	}



}
