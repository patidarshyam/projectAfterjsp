package com.yash.cms.dao;
import java.util.List;

import com.yash.cms.model.User;
/**
 * This interface perform the operation related to users.
 * @author shyam.patidar
 *
 */
public interface UserDAO {
	/**
	 * This will add the user into DB
	 * @param user Object
	 */
	public void insert(User user);
	/**
	 * This will delete the user from DB
	 * @param userId
	 */
	public void delete(Integer userId);
	/**
	 * This will delete the user from DB
	 * @param user object
	 */
	public void delete(User user);
	/**
	 * This will update the user into DB
	 * @param userId
	 */
	public void update(Integer userId);
	/**
	 * This will List users from the users table from DB
	 * @return
	 */
	public List<User> list();

}
