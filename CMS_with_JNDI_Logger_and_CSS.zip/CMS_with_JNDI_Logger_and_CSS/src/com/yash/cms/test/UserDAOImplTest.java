package com.yash.cms.test;

import com.yash.cms.dao.UserDAO;
import com.yash.cms.daoimpl.UserDAOImpl;
import com.yash.cms.model.User;
import com.yash.cms.service.UserService;
import com.yash.cms.serviceimpl.UserServiceImpl;

public class UserDAOImplTest {

	public static void main(String[] args) {
		UserService userService=new UserServiceImpl();
		User user = new User();
		user.setName("Man");
		user.setContact("5654666363");
		user.setLoginName("man");
		user.setPassword("man123");
		userService.registerUser(user);
	}

}
