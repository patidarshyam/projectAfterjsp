package com.yash.cms.test;

import com.yash.cms.daoimpl.ContactDAOImpl;

public class ContactDeleteTest {

	public static void main(String[] args) {
		Integer a= new Integer(3);
		ContactDAOImpl obj= new ContactDAOImpl();
		obj.delete(a);

	}

}
