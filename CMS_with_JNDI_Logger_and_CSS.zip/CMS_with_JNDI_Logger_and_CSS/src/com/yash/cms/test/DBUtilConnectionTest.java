package com.yash.cms.test;

import java.sql.*;
import com.yash.cms.util.DBUtil;

public class DBUtilConnectionTest {

	public static void main(String[] args) {
//	PreparedStatement	pstmt=DBUtil.createPreparedstatement("insert into users(name,contact,loginName,password)values('rahul','56546666','rahul','rahul123')");
//		try {
//			System.out.println( pstmt.execute());
//		
//		} catch (SQLException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
	}

}
