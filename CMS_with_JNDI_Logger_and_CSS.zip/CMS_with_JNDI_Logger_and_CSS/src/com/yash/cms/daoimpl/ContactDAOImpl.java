package com.yash.cms.daoimpl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.yash.cms.dao.ContactDAO;
import com.yash.cms.model.Contact;
import com.yash.cms.model.User;
import com.yash.cms.util.DBUtil;

public class ContactDAOImpl implements ContactDAO {
	private static Logger logger= Logger.getLogger(ContactDAOImpl.class);
	@Override
	public void insert(Contact contact) {
		PreparedStatement	pstmt=null;
		String sql="insert into contacts(name,contact,address,email,userId)values(?,?,?,?,?)";
		pstmt=DBUtil.createPreparedstatement(sql);
		try {
			pstmt.setString(1, contact.getName());
			pstmt.setString(2, contact.getContact());
			pstmt.setString(3, contact.getAddress());
			pstmt.setString(4, contact.getEmail());
			pstmt.setInt(5, contact.getUserId());
			pstmt.execute();
			logger.info("Data inserted SucessFully!!!");
		} catch (SQLException e) {
			logger.error("Error : "+e);
		}
	}

	@Override
	public List<Contact> listContact(Integer userId) {
		PreparedStatement	pstmt=null;
		List<Contact> contacts =new ArrayList<Contact>();
		try {
		String sql="select * from contacts where userId=?";
		pstmt=DBUtil.createPreparedstatement(sql);
		pstmt.setInt(1, userId);
		ResultSet rs= pstmt.executeQuery();
		while(rs.next()){
			Contact contact=new Contact();
			contact.setId(rs.getInt("id"));
			contact.setName(rs.getString("name"));
			contact.setContact(rs.getString("contact"));
			contact.setEmail(rs.getString("email"));
			contact.setAddress(rs.getString("address"));
			contacts.add(contact);
		}
		logger.info("Contact List Prepared successfully");
		} catch (SQLException e) {
			logger.error("Error : "+e);
		}
		return contacts;
	}

	@Override
	public void delete(Integer contactId) {
		try {
			PreparedStatement	pstmt=null;
			String sql="delete from contacts where id=?";
			pstmt=DBUtil.createPreparedstatement(sql);
			pstmt.setInt(1, contactId);
			pstmt.execute();
			logger.info("Contact deleted SucessFully!!!");
		} catch (SQLException e) {
			logger.error("Error : "+e);
		}
		
	}

	@Override
	public void update(Contact contact) {
		try {
			PreparedStatement	pstmt=null;
			String sql="UPDATE contacts SET name=?,contact=?,address=?,email=? WHERE id=?";
			pstmt=DBUtil.createPreparedstatement(sql);
			pstmt.setString(1,contact.getName() );
			pstmt.setString(2, contact.getContact());
			pstmt.setString(3,contact.getAddress());
			pstmt.setString(4, contact.getEmail());
			pstmt.setInt(5, contact.getId());
			pstmt.execute();
			logger.info("Contact updated SucessFully!!!");
		} catch (SQLException e) {
			logger.error("Error : "+e);
		}
	}

	@Override
	public Contact select(Integer contactId) {
		PreparedStatement	pstmt=null;
		Contact contact=null;
		try {
			String sql="select * from contacts where id=?";
			pstmt=DBUtil.createPreparedstatement(sql);
			pstmt.setInt(1, contactId);
			ResultSet rs= pstmt.executeQuery();
			
			if(rs.next()){
				contact=new Contact();
				contact.setId(rs.getInt("id"));
				contact.setName(rs.getString("name"));
				contact.setContact(rs.getString("contact"));
				contact.setEmail(rs.getString("email"));
				contact.setAddress(rs.getString("address"));
			}
			logger.info("Select Contact run successfully! ");	
			} catch (SQLException e) {
				logger.error("Error : "+e);
			}
			return contact;
	}

	@Override
	public List<Contact> listContact(String search, Integer userId) {
		PreparedStatement	pstmt=null;
		String likeSearch="%"+search+"%";
		List<Contact> contacts =new ArrayList<Contact>();
		try {
		String sql="SELECT * FROM contacts WHERE userId=? AND (NAME LIKE ? OR email LIKE ? OR address LIKE ? OR contact LIKE ?)";
		pstmt=DBUtil.createPreparedstatement(sql);
		pstmt.setInt(1, userId);
		pstmt.setString(2, likeSearch);
		pstmt.setString(3, likeSearch);
		pstmt.setString(4, likeSearch);
		pstmt.setString(5, likeSearch);
		ResultSet rs= pstmt.executeQuery();
		
		 
		while(rs.next()){
			Contact contact=new Contact();
			contact.setId(rs.getInt("id"));
			contact.setName(rs.getString("name"));
			contact.setContact(rs.getString("contact"));
			contact.setEmail(rs.getString("email"));
			contact.setAddress(rs.getString("address"));
			contacts.add(contact);
		}logger.info("Contact List prepared successfully!");
		} catch (SQLException e) {
			logger.error("Error : "+e);
		}
		return contacts;
	}

}
