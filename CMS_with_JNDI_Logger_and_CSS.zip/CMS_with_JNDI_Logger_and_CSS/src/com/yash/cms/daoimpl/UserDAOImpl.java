package com.yash.cms.daoimpl;

import java.sql.*;
import java.util.List;
import org.apache.log4j.Logger;
import com.yash.cms.dao.UserDAO;
import com.yash.cms.model.User;
import com.yash.cms.util.DBUtil;


/**
 * This class perform the operation related to users.
 * @author shyam.patidar
 *
 */
public class UserDAOImpl implements UserDAO {
	private static Logger logger= Logger.getLogger(UserDAOImpl.class);
	@Override
	public void insert(User user) {
		PreparedStatement	pstmt=null;
		String sql="insert into users(name,contact,loginName,password)values(?,?,?,?)";
		pstmt=DBUtil.createPreparedstatement(sql);
		try {
			pstmt.setString(1, user.getName());
			pstmt.setString(2, user.getContact());
			pstmt.setString(3, user.getLoginName());
			pstmt.setString(4, user.getPassword());
			pstmt.execute();
			logger.info("Data inserted SucessFully!!!");
		} catch (SQLException e) {
			logger.error("ERROR : "+ e);
		}
	
	}

	@Override
	public void delete(Integer userId) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void delete(User user) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void update(Integer userId) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<User> list() {
		// TODO Auto-generated method stub
		return null;
	}


}
