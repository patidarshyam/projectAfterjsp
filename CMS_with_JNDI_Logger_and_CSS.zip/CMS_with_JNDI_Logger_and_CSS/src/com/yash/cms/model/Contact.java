package com.yash.cms.model;
/**
 * This class will be work as a model object.
 * Its use is to travel data from one layer to another layer.
 * @author shyam.patidar
 *
 */
public class Contact extends Person {
	/**
	 * userId of the User
	 */
	private Integer userId;

	public Integer getUserId() {
		return userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}
	
}
