package com.yash.cms.model;
/**
 * This class will be work as a model object.
 * Its use is to travel data from one layer to another layer.
 * @author shyam.patidar
 *
 */
public class User extends Person {
	/**
	 * status of user like active or blocked
	 */
	private Integer status;
	/**
	 * role of user like Guest or Admin
	 */
	private Integer role;
	/**
	 * loginName of user
	 */
	private String loginName;
	/**
	 * password of user
	 */
	private String password;
	public User() {
		// TODO Auto-generated constructor stub
	}

	public Integer getStatus() {
		return status;
	}
	public void setStatus(Integer status) {
		this.status = status;
	}
	public Integer getRole() {
		return role;
	}
	public void setRole(Integer role) {
		this.role = role;
	}
	public String getLoginName() {
		return loginName;
	}
	public void setLoginName(String loginName) {
		this.loginName = loginName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	

}
