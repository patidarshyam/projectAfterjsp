package com.yash.cms.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.yash.cms.model.Contact;
import com.yash.cms.service.ContactService;
import com.yash.cms.serviceimpl.ContactServiceImpl;

/**
 * Servlet implementation class UpdateContactController
 */
@WebServlet("/UpdateContactController")
public class UpdateContactController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static Logger logger= Logger.getLogger(UpdateContactController.class);
	private ContactService contactService=null; 
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpdateContactController() {
        super();
        contactService=new ContactServiceImpl();
    }

//	@Override
//	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//		Integer contactId=Integer.parseInt(request.getParameter("id"));
//		Contact contact= contactService.getContact(contactId);
//		request.setAttribute("contact",contact);
//		request.getRequestDispatcher("AddContactController?msg=cUpdate").forward(request, response);
//		
//	}
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		logger.info("INFO : UpdateContactController run.");
		Integer contactId=Integer.parseInt(request.getParameter("id"));
		Contact contact= contactService.getContact(contactId);
		request.setAttribute("contact",contact);
		getServletContext().getRequestDispatcher("/addcontact.jsp?act=update&id="+contact.getId()).forward(request, response);
		
	}

}
